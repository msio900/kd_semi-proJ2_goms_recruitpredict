class ErrorCode:
    e0001 = '아이디가 중복 되었습니다. 다시 입력 하세요';
    e0002 = '삭제 중 오류';
    e0003 = 'ID 또는 Password가 틀렸습니다.';
